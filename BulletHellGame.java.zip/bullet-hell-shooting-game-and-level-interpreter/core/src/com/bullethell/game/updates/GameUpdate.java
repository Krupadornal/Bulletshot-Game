//package com.bullethell.game.updates;
//
//import com.bullethell.game.systems.ScoringSystem;
//public abstract class GameUpdate {
//    protected ScoringSystem sb;
//    public abstract void updateScore();
//    public abstract void updateHealth(); //lives
//}
