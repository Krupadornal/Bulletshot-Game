package com.bullethell.game.controllers;

public interface IShootable {
    public void shoot();
}
