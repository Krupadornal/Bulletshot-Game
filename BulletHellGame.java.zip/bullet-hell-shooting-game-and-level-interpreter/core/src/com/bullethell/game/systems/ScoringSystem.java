//package com.bullethell.game.systems;
//
//import com.bullethell.game.updates.GameUpdate;
//import org.json.*;
//
//
//public class ScoringSystem {
//    private int score;
//    private int lives;
//    private GameUpdate backScreen;
//
//    public ScoringSystem(JSONObject object) {
//        score = 0;
//        lives = ((Long) object.get("lives")).intValue();
//    }
//
//    public int getScore() {
//        return score;
//    }
//
//    public int getLives() {
//        return lives;
//    }
//
//}
